import logo from './logo.svg';
// import './App.css';

function demo() {
  return (
<div className="Body" style={{width: 1172.85, height: 1530.88, padding: 6, background: 'white', borderRadius: 72.47, justifyContent: 'flex-start', alignItems: 'center', gap: 10, display: 'inline-flex'}}>
  <div className="ScreenFrame" style={{width: 1160.53, height: 1518.93, background: '#D2D2D9', borderRadius: 71.02}}></div>
  <div className="IosIpadStatusBar" style={{paddingLeft: 16, paddingRight: 16, paddingTop: 5, paddingBottom: 5, justifyContent: 'center', alignItems: 'flex-start', gap: 790, display: 'flex'}}>
    <div className="Left" style={{alignSelf: 'stretch', justifyContent: 'flex-start', alignItems: 'center', gap: 12, display: 'inline-flex'}}>
      <div className="41Am" style={{color: 'black', fontSize: 12, fontFamily: 'SF Pro Text', fontWeight: '600', wordWrap: 'break-word'}}>9:41 AM</div>
      <div className="MonJul06" style={{color: 'black', fontSize: 12, fontFamily: 'SF Pro Text', fontWeight: '600', wordWrap: 'break-word'}}>Mon Jul 06</div>
    </div>
    <div className="Right" style={{alignSelf: 'stretch', justifyContent: 'flex-end', alignItems: 'center', gap: 4, display: 'inline-flex'}}>
      <div className="PrivacyIndicatorNone" style={{width: 6, height: 6, justifyContent: 'center', alignItems: 'center', display: 'flex'}}>
        <div className="Ellipse4" style={{width: 6, height: 6, borderRadius: 9999}} />
      </div>
      <div className="Sim1SingleSim" style={{width: 20, height: 14, paddingLeft: 0.45, paddingRight: 0.45, paddingTop: 1, paddingBottom: 1, justifyContent: 'center', alignItems: 'flex-end', gap: 2.10, display: 'flex'}}>
        <div className="Bar1" style={{width: 3.20, height: 4.60, background: 'black', borderRadius: 1}} />
        <div className="Bar2" style={{width: 3.20, height: 7, background: 'black', borderRadius: 1}} />
        <div className="Bar3" style={{width: 3.20, height: 9.60, background: 'black', borderRadius: 1}} />
        <div className="Bar4" style={{width: 3.20, height: 12, background: 'black', borderRadius: 1}} />
      </div>
      <div className="NetworkWifiFull" style={{width: 20, height: 12, paddingLeft: 2.16, paddingRight: 2.16, paddingTop: 0.50, paddingBottom: 0.50, justifyContent: 'center', alignItems: 'center', display: 'flex'}}>
        <div className="Group3" style={{width: 15.68, height: 11, position: 'relative'}}>
          <div className="Path" style={{width: 4.81, height: 3.37, left: 5.43, top: 7.63, position: 'absolute', background: 'black'}}></div>
          <div className="Path" style={{width: 10.25, height: 3.65, left: 2.71, top: 3.82, position: 'absolute', background: 'black'}}></div>
          <div className="Path" style={{width: 15.68, height: 4.75, left: 0, top: 0, position: 'absolute', background: 'black'}}></div>
        </div>
      </div>
      <div style={{textAlign: 'right', color: 'black', fontSize: 12, fontFamily: 'SF Pro Text', fontWeight: '500', wordWrap: 'break-word'}}>100%</div>
      <div className="BatteryFullUncharged" style={{width: 28, height: 14, position: 'relative'}}>
        <div className="BatteryFill" style={{width: 21, height: 9, left: 2, top: 2.50, position: 'absolute', background: 'black', borderRadius: 1.33}} />
        <img className="BatteryFrame" style={{width: 27.50, height: 13, left: 0, top: 0.50, position: 'absolute', opacity: 0.40}} src="https://via.placeholder.com/27x13" />
      </div>
    </div>
  </div>
  <div className="ScreenReplaceHere" style={{width: 1069.92, height: 1429.75, background: 'white', borderRadius: 19.57}} />
  <div className="Frame10" style={{width: 717, height: 1196, position: 'relative'}}>
    <img className="Lab11" style={{width: 358, height: 157, left: 180, top: 0, position: 'absolute'}} src="https://via.placeholder.com/358x157" />
    <div className="Login" style={{left: 315, top: 1134, position: 'absolute', color: 'white', fontSize: 32, fontFamily: 'Inter', fontWeight: '700', wordWrap: 'break-word'}}>Login</div>
    <div className="WelcomeBackGkblabs" style={{left: 152, top: 170, position: 'absolute', color: 'black', fontSize: 35, fontFamily: 'Inter', fontWeight: '600', wordWrap: 'break-word'}}>Welcome back,GKBlabs!</div>
    <div className="GetItStraight" style={{left: 257, top: 237, position: 'absolute', color: 'black', fontSize: 29, fontFamily: 'Inter', fontWeight: '700', wordWrap: 'break-word'}}>Get IT straight</div>
    <div className="ForgotPassword" style={{left: -0.19, top: 322.38, position: 'absolute', color: '#1D1B20', fontSize: 36, fontFamily: 'Inter', fontWeight: '600', wordWrap: 'break-word'}}>Forgot Password</div>
    <div className="EnterYourEmailAddressAndWeLlSendYouA" style={{left: 0, top: 416, position: 'absolute', color: 'black', fontSize: 32, fontFamily: 'Inter', fontWeight: '400', wordWrap: 'break-word'}}>Enter your email address and we`ll send you a</div>
  </div>
  <div className="SendEmail" style={{color: 'white', fontSize: 32, fontFamily: 'Inter', fontWeight: '700', wordWrap: 'break-word'}}>Send Email</div>
</div>
  );
}

export default demo;