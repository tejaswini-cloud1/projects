<img className="React1" style={{width: 166, height: 117, borderRadius: 27}} src="https://via.placeholder.com/166x117" />
<div className="Rectangle1" style={{width: 763, height: 67, background: '#D9D9D9'}} />
<img className="Google1" style={{width: 71, height: 60, borderRadius: 50}} src="https://via.placeholder.com/71x60" />
<div className="Rectangle2" style={{width: 763, height: 74, background: '#D9D9D9'}}></div>
<img className="FacebookLogo1" style={{width: 60, height: 55, borderRadius: 50}} src="https://via.placeholder.com/60x55" />
<div className="Email" style={{width: 70, height: 25, color: 'black', fontSize: 20, fontFamily: 'Inter', fontWeight: '400', wordWrap: 'break-word'}}>EMAIL</div>
<div className="Rectangle3" style={{width: 763, height: 59, background: '#D9D9D9'}} />
<div className="Or" style={{width: 48, height: 46, color: 'black', fontSize: 20, fontFamily: 'Inter', fontWeight: '400', wordWrap: 'break-word'}}>(OR)<br/></div>
<div className="FullName" style={{width: 132, height: 23, color: 'black', fontSize: 20, fontFamily: 'Inter', fontWeight: '400', wordWrap: 'break-word'}}>FULL NAME</div>
<div className="Rectangle4" style={{width: 763, height: 63, background: '#D9D9D9'}} />
<div className="Password" style={{width: 130, height: 24, color: 'black', fontSize: 20, fontFamily: 'Inter', fontWeight: '400', wordWrap: 'break-word'}}>PASSWORD</div>
<div className="Rectangle5" style={{width: 763, height: 56, background: '#D9D9D9'}} />
<div className="SignInWithYourGoogleAccount" style={{width: 551, height: 27, color: 'black', fontSize: 24, fontFamily: 'Inter', fontWeight: '400', wordWrap: 'break-word'}}>SIGN IN WITH YOUR GOOGLE ACCOUNT</div>
<div className="SignInWithYourFacebookAccount" style={{width: 582, height: 28, color: 'black', fontSize: 24, fontFamily: 'Inter', fontWeight: '400', wordWrap: 'break-word'}}>SIGN IN WITH YOUR FACEBOOK ACCOUNT</div>
<div className="Rectangle6" style={{width: 406, height: 57, background: 'rgba(193.52, 31.34, 219.92, 0.56)', borderRadius: 20}} />
<div className="Submit" style={{width: 104, height: 30, color: 'black', fontSize: 24, fontFamily: 'Inter', fontWeight: '400', wordWrap: 'break-word'}}>SUBMIT</div>
<div className="AllreadyHaveAnAccountSignIn" style={{width: 505, height: 32, color: 'black', fontSize: 24, fontFamily: 'Inter', fontWeight: '400', wordWrap: 'break-word'}}>ALLREADY HAVE AN ACCOUNT?  sign in</div>