import logo from './logo.svg';
import './App.css';

function App() {
  return (
    <div className="Desktop5" style={{width: 1440, height: 1024, position: 'relative', background: 'white'}}>
  <div className="Rectangle6"/>
  <a href='#'><button className='resetbutton' style={{  left: 720,  position: 'absolute', background: '#1487CA', borderRadius: 10, border: '1px rgba(0, 0, 0, 0.12) solid'}}>Reset Password</button></a>
  <div className="Reset" style={{left: 908, top: 540, position: 'absolute', textAlign: 'center', color: 'white', fontFamily: 'Inter', fontWeight: '700', wordWrap: 'break-word'}}></div>
  <div className="GetItStraight" style={{left: 113, position: 'absolute', color: 'black',  fontFamily: 'Inter', fontWeight: '400', wordWrap: 'break-word'}}>Get IT straight</div>
  <div className="Rectangle19" style={{ }}></div>
  <input className="text"  type="password" placeholder=". . . . . . . ." style={{ left: 720, top: 600, position: 'absolute', background: 'white', borderRadius: 10, border: '1px rgba(0, 0, 0, 0.30) solid'}} />
  
  {/* <div className="Text" style={{left: 821, top: 532, position: 'absolute', textAlign: 'center'}}></div> */}
  <div className="ConfirmPassword" style={{left: 726, top: 380, position: 'absolute', textAlign: 'center', color: 'black',fontFamily: 'Inter', fontWeight: '600', wordWrap: 'break-word'}}>Confirm Password</div>
  <div className="Password" style={{left: 726, top:250, position: 'absolute', textAlign: 'center', color: 'black',  fontFamily: 'Inter', fontWeight: '600', wordWrap: 'break-word'}}>Password</div>
  <div className="Text" style={{left: 983, top: 349, position: 'absolute', textAlign: 'center', color: 'black',  fontFamily: 'Inter', fontWeight: '400', wordWrap: 'break-word'}}><br/></div>
  <div className="ResetPassword" style={{left: 720, top:130  , position: 'absolute', textAlign: 'center', color: 'black',  fontFamily: 'Inter', fontWeight: '500', wordWrap: 'break-word'}}>Reset Password</div>
  <div className="Rectangle20" style={{ }} />
  <input className="text2"  type="password" placeholder=". . . . . . . ." style={{ left: 720, top:450, position: 'absolute', background: 'white', borderRadius: 10, border: '1px rgba(0, 0, 0, 0.30) solid'}} />
 
  <div className="EnterTheNewPasswordThePasswordMustContain" style={{left: 720, top:180, position: 'absolute', textAlign: 'center', color: 'black', fontFamily: 'Inter', fontWeight: '400', wordWrap: 'break-word'}}>Enter the new password. The password must contain</div>
  <div className="AtLeast8Characters" style={{left: 721, top:210, position: 'absolute', textAlign: 'center', color: 'black', fontFamily: 'Inter', fontWeight: '400', wordWrap: 'break-word'}}>at least 8 characters</div>
  <div className="WelcomeBackToGkbLabs" style={{width: 396, left: 113, fontSize:60, position: 'absolute', color: 'black', fontFamily: 'Poppins', fontWeight: '600', wordWrap: 'break-word'}}>Welcome back,<br/>to GKB Labs!</div>
  <img className="WhatsappImage20240705At43519Pm2" style={{width: 527, height: 300, left: 50,  position: 'absolute'}} src="./gkb.jpg" />
</div>
  );
}

export default App;
