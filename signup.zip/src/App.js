import logo from './logo.svg';
import './App.css';

function App() {
  return (
    <div className="Desktop2" style={{width: 1440, height: 1024, position: 'relative', background: 'white'}}>
  <img className="WhatsappImage20240705At43519Pm1" style={{ left: 26, top: 149, position: 'absolute'}} src="./gkb_labs.jpeg" />
  <div className="Frame5" style={{height: 116, left: 725, top: 146, position: 'absolute', flexDirection: 'column', justifyContent: 'center', alignItems: 'center', gap: 20, display: 'inline-flex'}}>
    <div className="Frame4" style={{width: 550, height: 46, position: 'relative'}}>
      <div className="Rectangle1"  />
      <button className='googlelogin'>Log in with Google</button>
      <div className="LogInWithGoogle" style={{left: 212, position: 'absolute', color: 'black',  fontFamily: 'Inter', fontWeight: '500', wordWrap: 'break-word'}}></div>
      <img className="Google2" style={{ left: 100,  position: 'absolute', borderRadius: 50}} src="./google.png" />
    </div>
    <div className="Frame5" style={{width: 550, height: 50, position: 'relative'}}>
      <div className="Rectangle2"  />
     
      <button className='facebooklogin'>Log in with FaceBook</button>
       <div className="LogInWithFacebook" style={{left: 212,  position: 'absolute', color: 'black', fontFamily: 'Inter', fontWeight: '500', wordWrap: 'break-word'}}></div>
      <img className="FacebookLogo2" style={{ left: 100, position: 'absolute', borderRadius: 50}} src="./facebook.jpg" />
    </div>
  </div>
  <div className="Group2" style={{width: 410, height: 17, left: 790,position: 'absolute'}}>
    <div className="Line3" style={{ position: 'absolute', border: '1px rgba(0, 0, 0, 0.20) solid'}}></div>
    <div className="Line4" style={{ position: 'absolute', border: '1px rgba(0, 0, 0, 0.20) solid'}}></div>
    <div className="Or" style={{ left: 194.63,  position: 'absolute', textAlign: 'center', color: 'rgba(0, 0, 0, 0.50)', fontFamily: 'Inter', fontWeight: '700', wordWrap: 'break-word'}}>OR</div>
  </div>
  <div className="Frame11" style={{left: 816, top: 364, position: 'absolute', flexDirection: 'column', justifyContent: 'center', alignItems: 'flex-start', gap: 20, display: 'inline-flex'}}>
    <div className="Frame8" style={{width: 358, height: 72, position: 'relative'}}>
      <div className="Rectangle3"  />
      <div className="GkbLabs" style={{ position: 'absolute', color: 'rgba(0, 0, 0, 0.50)', fontFamily: 'Inter', fontWeight: '400', wordWrap: 'break-word'}}></div>
      <input type="text" className="text" style={{ position: 'absolute', background: 'white', borderRadius: 10, border: '1px rgba(0, 0, 0, 0.30) solid'}} placeholder="GKB"/>
    </div>
    <div className="Frame9" style={{width: 358, height: 72, position: 'relative'}}>
      <div className="Rectangle4" />
      <div className="GkblabsGmailCom" style={{ position: 'absolute', color: 'rgba(0, 0, 0, 0.50)',  fontFamily: 'Inter', fontWeight: '400', wordWrap: 'break-word'}}></div>
      <input type="email" className="text2" style={{ position: 'absolute', background: 'white', borderRadius: 10, border: '1px rgba(0, 0, 0, 0.30) solid'}} placeholder="gkblabs@gmail.com"/>
    </div>
  </div>
  <div className="Email" style={{  position: 'absolute', color: 'black', fontFamily: 'Inter', fontWeight: '600', wordWrap: 'break-word'}}>Email</div>
  <div className="FullName" style={{  top:200, position: 'absolute', color: 'black',  fontFamily: 'Inter', fontWeight: '600', wordWrap: 'break-word'}}>Full Name</div>
  <div className="Frame11" style={{width: 546, height: 180, left: 720, top: 557, position: 'absolute', flexDirection: 'column', justifyContent: 'center', alignItems: 'flex-start', gap: 20, display: 'inline-flex'}}>
    <div className="Frame7" style={{paddingTop: 23.50, justifyContent: 'flex-end', alignItems: 'center', display: 'inline-flex'}}>
      <div className="Rectangle5"  />
      <input type="password" className="text3" style={{ position: 'absolute', background: 'white', borderRadius: 10, border: '1px rgba(0, 0, 0, 0.30) solid'}} placeholder=". . . . . . ."/>
    </div>
    <div className="Frame6" style={{width: 358, height: 72, position: 'relative'}}>
      <div className="Rectangle6" />
      <div className="ConfirmPassword" style={{ position: 'absolute', color: 'black',  fontFamily: 'Inter', fontWeight: '600', wordWrap: 'break-word'}} >Confirm Password</div>
      <div className="Dot1"style={{ position: 'absolute', color: 'black', fontFamily: 'Inter', fontWeight: '800', wordWrap: 'break-word'}}></div>
      <div className="Dot2" style={{ position: 'absolute', color: 'black',  fontFamily: 'Inter', fontWeight: '800', wordWrap: 'break-word'}}></div>
      <input type="password" className="text4" style={{ position: 'absolute', background: 'white', borderRadius: 10, border: '1px rgba(0, 0, 0, 0.30) solid'}} placeholder=". . . . . . ."/>
    </div>
  </div>

  <div className="Password" style={{ position: 'absolute', color: 'black', fontFamily: 'Inter', fontWeight: '600', wordWrap: 'break-word'}}>Password</div>
  <div className="Group3" style={{width: 550, height: 72, left: 720, top: 796, position: 'absolute'}}>
    <div className="Rectangle7"  />
    <button className='signupbutton' style={{ position: 'absolute',backgroundcolor:'rgb(69, 18, 151)'}}>Sign Up</button>
    <div className="DonTHaveAnAccount" style={{ position: 'absolute', color: 'rgba(0, 0, 0, 0.50)',  fontFamily: 'Inter', fontWeight: '400', wordWrap: 'break-word'}}>Don’t have an account?</div>
    <div className="SignUpForFree" style={{ position: 'absolute', color: '#1487CA',  fontFamily: 'Inter', fontWeight: '700', wordWrap: 'break-word'}}>Sign up for free</div>
    <div className="SignUp" style={{ position: 'absolute', color: 'white',  fontFamily: 'Inter', fontWeight: '700', wordWrap: 'break-word'}}></div>
  </div>
  <div className="GetItStraight" style={{left: 113, top: 508, position: 'absolute', color: 'black',  fontFamily: 'Inter', fontWeight: '400', wordWrap: 'break-word'}}>Get IT straight</div>
  <div className="WelcomeBackToGkbLabs" style={{width: 396, left: 113, top: 379, position: 'absolute', color: 'black',  fontFamily: 'Poppins', fontWeight: '600',  wordWrap: 'break-word'}}>Welcome back,<br/>to GKB Labs!</div>
</div>
  );
}

export default App;
